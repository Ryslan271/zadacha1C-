﻿using System;
using System.Linq;

namespace _10_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mas = { { 1, 2, 5, 3 }, { 4, 5, 7, 6 } };

            int rows = mas.GetUpperBound(0) + 1; // строки
            int columns = mas.Length / rows; // количество элементов в каждой строке
            int min = 0;

            for (int i = 0; i < rows; i++)
            {
                min = mas[i, 0];

                for (int j = 0; j < columns; j++)
                {
                    if (min > mas[i, j])
                    {
                        min = mas[i, j];
                    }
                }
                Console.WriteLine("min: {0}", min);
            }

            Console.ReadKey();
        }
    }
}
