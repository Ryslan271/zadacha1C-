﻿using System;

namespace _3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mas = { { 1, 2, 3, 11 }, { 4, 5, 6, 11 }};

            int rows = mas.GetUpperBound(0) + 1;
            int columns = mas.Length / rows;
            int index = 0;
            int index1 = 0;
            bool flag = false;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    if (mas[i, j] > 10)
                    {
                        if (index1 == index)
                        {
                            break;
                        }
                        index1 = index;
                        index = 0;
                        break;
                    }

                    index++;
                }
                
                if (index1 == index)
                {
                    flag = true;
                    break;
                }
            }
            if (flag) Console.WriteLine(index + 1);
            else Console.WriteLine("Нет такого числа (");
        }
    }
}
