﻿using System;
using System.Linq;

namespace _9_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { 5, 2, 3, 4, 5, 6, 5, 8, 9, 5, 8 };

            Console.WriteLine(arrs.Max() - arrs.Min());

        }
    }
}
