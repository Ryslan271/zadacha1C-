﻿using System;
using System.Collections.Generic;

namespace _1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mas = { { 1, 2, 3, 4 },
                           { 1, 2, 3, 4 } };
            int sum;
            for (int j = 0; j < mas.GetLength(1); ++j)
            {
                sum = 0;
                for (int i = 0; i < mas.Rank; ++i)
                {
                    sum += mas[i, j];
                }

                Console.WriteLine(sum);

            }
            Console.ReadKey();
        }
    }
}
