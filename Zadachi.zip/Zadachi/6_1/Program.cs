﻿using System;

namespace _6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[] { 1, 2, 3, 11, 12, 13, 14, 15,
                                        16, 17, 18, 19, 20, 21, 23, 24, 25, 26, 27, 28, 29, 30 };

            for(int i = 0; i < numbers.Length; i++)
            {
                if (Array.IndexOf(numbers, i + 1) == -1)
                {
                    Console.WriteLine(i + 1);
                }
            }
        }
    }
}
