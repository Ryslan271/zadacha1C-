﻿using System;
using System.Collections.Generic;

namespace _2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { 5, 2, 3, 4, 5, 6, 7, 8, 8, 8, 5 };
            int count = 0;
            List<string> indexs = new List<string>();

            for ( int i = 0; i < arrs.Length; i++)
            {
                if(arrs[i] == 5)
                {
                    count++;
                    indexs.Add(Convert.ToString(i));
                }
            }

            Console.WriteLine(count);

            foreach (string i in indexs)
            {
                Console.Write("{0} ", i);
            }
            Console.ReadKey();

        }
    }
}
