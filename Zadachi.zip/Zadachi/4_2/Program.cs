﻿using System;

namespace _4_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mas = { { 1, 20, 3, 11, 1 },
                        { 1, 21, 3, 11, 12 } };
            bool isTrue;
            int maxIndex = -1;
            for (int j = 0; j < mas.GetLength(1); ++j)
            {
                isTrue = true;
                for (int i = 0; i < mas.Rank; ++i)
                {
                    if (mas[i, j] <= 10)
                    {
                        isTrue = false;
                        break;
                    }
                }
                if (isTrue)
                {
                    maxIndex = j;
                }

            }
            Console.WriteLine(maxIndex != -1 ? (maxIndex + 1).ToString() : "Такого столбца не существует");
        }
    }
}
