﻿using System;

namespace _3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите длинну масиива:");
            int lon = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Введите K:");
            int k = Convert.ToInt32(Console.ReadLine());

            int[] mass = new int[lon];
            for (int i = 0; i < lon; i++)
            {
                mass[i] = i + 1;
            }

            int sum = 0, number = 0;

            for( int i = 0; i < mass.Length; i++)
            {
                if (mass[i] >= k)
                {
                    number++;
                    sum += mass[i];
                }
            }

            Console.WriteLine(sum / number);

        }
    }
}
