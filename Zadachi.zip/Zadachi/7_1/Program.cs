﻿using System;

namespace _7_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { 1, 2, 3, 4, 5 };

            int temp = 0, i1 = 0;

            for (int i = 0; i < arrs.Length / 2; i++)
            {
                temp = arrs[i * 2 + 1];
                arrs[i * 2 + 1] = arrs[i * 2];
                arrs[i * 2] = temp;
            }
                
            foreach(int i in arrs)
            {
                Console.Write("{0} ", i);
            }

            Console.ReadKey();
        }
    }
}
