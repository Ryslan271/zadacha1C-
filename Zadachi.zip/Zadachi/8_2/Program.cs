﻿using System;

namespace _8_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] massive = new int[5, 5];
            int elem = 30;

            for (int i = 0; i < 5; ++i)
            {
                for (int j = 0; j < 5; ++j)
                {
                    massive[i, j] = elem;
                    elem++;
                }
            }

            for (int i = 0; i < 5; ++i)
            {
                for (int j = 0; j < 5; ++j)
                {
                    Console.Write($"{massive[i, j]} ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
