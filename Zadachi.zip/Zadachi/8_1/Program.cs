﻿using System;

namespace _8_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { 5, 2, 3, 4, 5, 6, 5, 8, 8, 5, 8 };
            int index = 0;
            bool f = true;

            for (int i = 0; i < arrs.Length; i++)
            {
                if (arrs[i] == 5)
                {
                    index = i;
                }
                if (f)
                {
                    Console.WriteLine(index);
                    f = false;
                }
            }
            Console.WriteLine(index);
        }
    }
}
