﻿using System;

namespace _10_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { 1, 2, 3, 4, 5, 6, 1, 2, 3, 6 };

            for (int i = 0; i < arrs.Length; i++)
            {
                if ((i + 1) % 3 == 0)
                {
                    Console.WriteLine(arrs[i - 2] + arrs[i - 1] + arrs[i]);
                }
            }
            Console.ReadKey();
        }
    }
}
