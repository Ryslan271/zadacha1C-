﻿using System;

namespace Zadachi
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { 8, 2, 3, 4, 5, 6, 7, 8, 8, 8, 8 };
            int index = 0;

            int max = arrs[0];

            for (int i = 0; i < arrs.Length; i++)
            {
                if (max < arrs[i])
                {
                    max = arrs[i];
                }
            }
            Console.Write("номера элементов в массиве равные max: ");
            foreach (int i in arrs)
            {
                if (i == max)
                {
                    Console.Write("{0} ", index);
                }
                index++;
            }

            Console.WriteLine();
            Console.WriteLine($"max : {max}");
            
            Console.ReadKey();
        }
    }
}
