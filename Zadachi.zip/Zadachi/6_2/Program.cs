﻿using System;

namespace _6_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mas = { { 3, 4, 3, 11 },
                           { 1, 2, 3, 5 } };
            int sum;
            for (int j = 0; j < mas.GetLength(1); ++j)
            {
                sum = 0;
                for (int i = 0; i < mas.Rank; ++i)
                {
                    sum += mas[i, j];
                }

                Console.Write("{0} ", sum / 2);

            }
            Console.ReadKey();
        }
    }
}
