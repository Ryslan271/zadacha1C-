﻿using System;

namespace _9_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mas = { { 1, 2, 5, 3 }, { 4, 5, 7, 6 } };

            int rows = mas.GetUpperBound(0) + 1; // строки
            int columns = mas.Length / rows; // количество элементов в каждой строке
            int max = 0;

            for (int i = 0; i < rows; i++)
            {
                max = mas[i, 0];

                for (int j = 0; j < columns; j++)
                {
                    if (max < mas[i, j])
                    {
                        max = mas[i, j];
                    }
                }
                Console.WriteLine("max: {0}", max);
            }

            Console.ReadKey();
        }
    }
}
