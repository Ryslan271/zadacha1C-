﻿using System;

namespace _5_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { 87, 2, 3, 47, 5, 6, 47, 8, 7, 5, 8 };

            int seven = 0;
            bool flag = false;

            for (int i = 0; i < arrs.Length; i++)
            {
                char[] number = Convert.ToString(arrs[i]).ToCharArray();
                foreach(char j in number)
                {
                    if (j == '7')
                    {
                        seven = arrs[i];
                        flag = true;
                    }
                }
            }
            if (flag)
            {
                int index = Array.IndexOf(arrs, seven);
            
                for (int i = 0; i < arrs.Length; i++)
                {
                    if (index < i)
                    {
                        Console.Write("{0} ", arrs[i]);
                    }
                }
            }
            else
            {
                Console.WriteLine();
            }
        }
    }
}
