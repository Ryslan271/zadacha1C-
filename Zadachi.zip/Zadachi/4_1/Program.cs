﻿using System;

namespace _4_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrs = new int[] { -8, -2, -3, -4, -5, -6, -7, -8, -8, 8, 2 };
            int sum = 0, number = 0;

            foreach (int i in arrs)
            {
                if (i >= 0)
                {
                    number++;
                    sum += i;
                }
            }

            Console.WriteLine(sum / number);

        }
    }
}
