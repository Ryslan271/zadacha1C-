﻿using System;

namespace _7_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Количество элментов в масииве: ");
            int elem = Convert.ToInt32(Console.ReadLine());

            int[,] massive = new int[elem / 2, 2];

            for (int i = 0; i < 2; ++i)
            {
                for (int j = 0; j < elem / 2; ++j)
                {
                    massive[i, j] = 1;
                }
            }

            for (int i = 0; i < 2; ++i)
            {
                for (int j = 0; j < elem / 2; ++j)
                {
                    Console.Write($"{massive[i, j]} ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
