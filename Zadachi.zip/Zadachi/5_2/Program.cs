﻿using System;

namespace _5_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mas = { { 1, 2, 3, 4 },
                           { 1, 2, 3, 4 } };
            int composition;
            for (int j = 0; j < mas.GetLength(1); ++j)
            {
                composition = 1;
                for (int i = 0; i < mas.Rank; ++i)
                {
                    composition *= mas[i, j];
                }

                Console.Write("{0} " ,composition);

            }
            Console.ReadKey();
        }
    }
}
